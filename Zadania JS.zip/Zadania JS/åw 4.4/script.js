function start_anim() {
    const textElement = document.querySelector('.anim-txt');
    textElement.style.fontSize = '24px';
  }
  
  function reset_anim() {
    const textElement = document.querySelector('.anim-txt');
    textElement.style.fontSize = '16px';
  }