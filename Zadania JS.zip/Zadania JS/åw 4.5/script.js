function start_anim() {
    const imageElement = document.querySelector('.kot-anim');
    imageElement.style.animation = 'ruszenie-anim 1s forwards';
    
    
    imageElement.addEventListener('animationend', () => {
      imageElement.style.transform = 'translate(1600px, 0)';
      imageElement.style.animation = 'none';
    }, { once: true });
  }