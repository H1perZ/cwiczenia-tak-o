function start_anim() {
    const imageElement = document.querySelector('.pilka');
    imageElement.style.animation = 'move_pilka 0.75s forwards ';
    


}

